#include <cstdio>
#include <cstdlib>
#include <algorithm>

#include <mpi.h>
#include <common.h>

int 
main(int argc, char** argv) {
  // Initialize
  MPI_Init(&argc, &argv);

  int rank, npes;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &npes);

  // main body ...
  srand(6965 + rank);

  int i;
  int * a = (int *) malloc(n*sizeof(int));
  
  for (i=0; i<n; ++i) {
    a[i] = rand();
  }

  //! implement $k$-select
  
  // 1. Select splitters ...
  qsort(a, n, sizeof(int), compare);
  int pivot = a[n/2];

  int *samples = (int *) malloc ( npes * sizeof(int));
  MPI_Allgather(&pivot, 1, MPI_INT, samples, 1, MPI_INT, MPI_COMM_WORLD);
  
  // lets rank the splitters ...
  int *sranks, *gsranks;
  
  sranks = (int *) malloc (npes* sizeof(int));
  gsranks = (int *) malloc (npes* sizeof(int));

  // compute local ranks
  for (i=0; i<npes; ++i) 
    sranks[i] = std::lower_bound(a, a+n, samples[i]) - a;
  
  MPI_Allreduce(sranks, gsranks, npes, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

  // find splitter closest to k
  int k=n*npes/2;
  int idx = 0, diff=n; 
  
  for (i=0; i<npes; ++i) {
    if ( abs(gsranks[i] - k) < diff ) {
      diff = abs(gsranks[i] - k);
      idx = i;
    }
  }

  if (!rank)
    printf("k-Splitter is %d, with rank %d, k = %d \n", samples[idx], gsranks[idx], k);

  // clean up 
  free(a);
  free(samples);
  free(sranks);
  free(gsranks);

  // All done
  MPI_Finalize();
  return 0;
}
