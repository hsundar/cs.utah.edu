#ifndef __common_h_
#define __common_h_

#define root 0
#define n 128

#define printline  if (!rank) printf("__________________________________________________________________________\n")


int 
compare (const void * a, const void * b) {
  return ( *(int*)a - *(int*)b );
}

#endif
