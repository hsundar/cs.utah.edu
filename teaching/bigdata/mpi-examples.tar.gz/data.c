#include <stdio.h>
#include <stdlib.h>

#include <mpi.h>

#include "common.h"

int 
main(int argc, char** argv) {
  // Initialize
  MPI_Init(&argc, &argv);

  int i;
  int rank, npes;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &npes);

  // main body ...
  srand(6965 + rank);

  int* a = (int *) malloc (n * sizeof(int) );

  for (i=0; i<n; ++i) {
    a[i] = rand();
  }

  //
  qsort(a, n, sizeof(int), compare);
  int pivot = a[n/2]; // is only imp on root.

  MPI_Bcast(&pivot, 1, MPI_INT, root, MPI_COMM_WORLD);

  int lt=0;
  for (i=0; i<n; ++i) 
    if (a[i] < pivot) lt++;

  int *counts = (int *) malloc (npes * sizeof(int) );
  MPI_Allgather (&lt, 1, MPI_INT, counts, 1, MPI_INT, MPI_COMM_WORLD);

  if (!rank) {
    for (i=0; i<npes; ++i)
      printf ("rank of pivot %d on process %d is %d\n", pivot, i, counts[i]); 
  }
  
  int * sbuf = (int *) malloc (npes * sizeof(int) );
  int * rbuf = (int *) malloc (npes * sizeof(int) );

  for (i=0; i<npes; ++i)
    sbuf[i] = a[counts[i]];

  MPI_Alltoall(sbuf, 1, MPI_INT, rbuf, 1, MPI_INT, MPI_COMM_WORLD);

  int *send_cnts; // npes
  int *send_buff; // of size n

  int * recv_cnts; // npes
  //! 1. first exchange send counts
  MPI_Alltoall(send_cnts, 1, MPI_INT, recv_cnts, 1, MPI_INT, MPI_COMM_WORLD);

  int *send_offsets, *recv_offsets; // size npes.
  send_offset[0] = 0;
  recv_offset[0] = 0;
  
  for (i=1; i<npes; ++i) {
    send_offset[i] = send_offset[i-1] + send_cnt[i];
    recv_offset[i] = recv_offset[i-1] + recv_cnt[i];
  }
  
  int * recv_buf = (int*) malloc (sizeof(int) * (recv_offset[npes-1] + recv_cnt[npes-1] ));

MPI_Alltoallv(send_buf, send_cnts, send_offset, MPI_INT, recv_buf, recv_cnts, recv_offset, MPI_INT, MPI_COMM_WORLD);
  

  free(a);
  free(counts);
  // All done
  MPI_Finalize();
  return 0;
}
