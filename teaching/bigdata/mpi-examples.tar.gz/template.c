#include <stdio.h>
#include <stdlib.h>

#include <mpi.h>

#include "common.h"

int 
main(int argc, char** argv) {
  // Initialize
  MPI_Init(&argc, &argv);

  int rank, npes;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &npes);

  // main body ...


  // All done
  MPI_Finalize();
  return 0;
}
