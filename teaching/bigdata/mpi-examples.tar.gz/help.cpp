

MPI_Barrier(MPI_COMM_WORLD);

MPI_Comm_split(MPI_COMM_WORLD, color, rank, &comm);

MPI_Bcast(buffer, count, datatype, root, MPI_COMM_WORLD);

MPI_Gather (sbuf, scnt, sdatatype, rbuf, rcnt, rdatatype, root, MPI_COMM_WORLD);

MPI_Scatter(sbuf, scnt, sdatatype, rbuf, rcnt, rdatatype, root, MPI_COMM_WORLD);

MPI_Allgather(sbuf, scnt, sdatatype, rbuf, rcnt, rdatatype, MPI_COMM_WORLD);

MPI_Alltoall(sbuf, scnt, sdatatype, rbuf, rcnt, rdatatype, MPI_COMM_WORLD);

MPI_Alltoallv(sendbuf, sendcounts, sdispls, sendtype, recvbuf, recvcounts, rdispls, recvtype, MPI_COMM_WORLD);

MPI_Reduce(send, result, cnt, datatype, Op, root, MPI_COMM_WORLD);


int * a = (int *) malloc(n*sizeof(int));
  
for (i=0; i<n; ++i) {
  a[i] = rand();
}
