#include <stdio.h>
#include <stdlib.h>

#include <mpi.h>

#include "common.h"

int 
main(int argc, char** argv) {
  // Initialize
  MPI_Init(&argc, &argv);

  int rank, npes;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &npes);

  // main body ...
  printf("I am process %d of %d\n", rank, npes); fflush(stdout);

  MPI_Barrier(MPI_COMM_WORLD);
  printline;
  MPI_Comm comm;
  MPI_Comm_split(MPI_COMM_WORLD, rank%3 , rank, &comm);

  int new_rank, new_npes;
  MPI_Comm_rank(comm, &new_rank);
  MPI_Comm_size(comm, &new_npes);
  
    printf("I was %d, I am now process %d of %d\n", rank, new_rank, new_npes); fflush(stdout);
  
  // All done
  MPI_Finalize();
  return 0;
}
